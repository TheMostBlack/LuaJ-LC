activity.Debug=true
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "res"
activity.setTitle("密码加入软件")
activity.setContentView(res.layout.layout)

进入.onClick=function()
  switch #密码.text
   case 0
    print("请输入密码")
   default
    switch 密码.text
     case "密码"
      activity.setContentView(res.layout.layout1)
     default
      print("密码错误")
    end
  end
end

--[[/**
*
*----------Dragon be here!----------/
* 　　　┏┓　　　┏┓
* 　　┏┛┻━━━┛┻┓
* 　　┃　　　　　　　┃
* 　　┃　　　━　　　┃
* 　　┃　┳┛　┗┳　┃
* 　　┃　　　　　　　┃
* 　　┃　　　┻　　　┃
* 　　┃　　　　　　　┃
* 　　┗━┓　　　┏━┛
* 　　　　┃　　　┃护国神兽保佑
* 　　　　┃　　　┃代码无BUG！
* 　　　　┃　　　┗━━━┓
* 　　　　┃　　　　　　　┣┓
* 　　　　┃　　　　　　　┏┛
* 　　　　┗┓┓┏━┳┓┏┛
* 　　　　　┃┫┫　┃┫┫
* 　　　　　┗┻┛　┗┻┛
* ━━━━━━神兽出没━━━━━━
*/]]