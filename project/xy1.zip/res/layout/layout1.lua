{
import "android.widget.*";
  LinearLayout;
  layout_width="fill";
  orientation="vertical";
  layout_height="fill";
  gravity="center";
  {
    TextView;
    text="密码正确的页面";
  };
};