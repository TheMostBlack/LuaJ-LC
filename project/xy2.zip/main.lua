import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.app.*"
import "android.graphics.Typeface"
import "android.content.Intent"
import "android.content.Context"
import "android.content.pm.PackageManager"
import "android.graphics.drawable.ColorDrawable"
import "android.content.Intent"
import "java.io.File"
import "com.androlua.LuaAdapter"
import "com.androlua.LuaUtil"
import "android.graphics.drawable.StateListDrawable"
import "android.graphics.drawable.GradientDrawable"
import "res"
import "res.layout.item"
activity.setTitle("美化路径模块")
activity.setContentView(res.layout.main)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xffffffff);
if tonumber(Build.VERSION.SDK) >= 23 then
  activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
end
--导入类
local context=activity or service

local LuaBitmap=luajava.bindClass "com.androlua.LuaBitmap"
local function loadbitmap(path)
  if not path:find("^https*://") and not path:find("%.%a%a%a%a?$") then
    path=path..".png"
  end
  if path:find("^https*://") then
    return LuaBitmap.getHttpBitmap(context,path)
   elseif not path:find("^/") then
    return LuaBitmap.getLocalBitmap(context,string.format("%s/%s",luajava.luadir,path))
   else
    return LuaBitmap.getLocalBitmap(context,path)
  end
end
import "android.widget.ArrayAdapter"
import "android.widget.LinearLayout"
import "android.widget.TextView"
import "java.io.File"
import "android.widget.ListView"
import "android.app.AlertDialog"
function ChoicePath(StartPath,callback)
  data={}
  adp=LuaAdapter(activity,data,item)
  lv.setAdapter(adp)
  function SetItem(path)
    path=tostring(path)
    adp.clear()--清空适配器
    cp.Text=tostring(path)--设置当前路径
    if path~="/" then--不是根目录则加上返回上级目录
      adp.add{file="返回上级目录",img="folder.png"}
    end
    ls=File(path).listFiles()
    if ls~=nil then
      ls=luajava.astable(File(path).listFiles()) --全局文件列表变量
      table.sort(ls,function(a,b)
        return (a.isDirectory()~=b.isDirectory() and a.isDirectory()) or ((a.isDirectory()==b.isDirectory()) and a.Name<b.Name)
      end)
     else
      ls={}
    end
    for index,c in ipairs(ls) do
      if c.isDirectory() then--如果是文件夹则
        adp.add{file=c.Name,img=loadbitmap(activity.getLuaDir().."/folder.png")}
       elseif c.isFile() then--如果是文件则
        adp.add{file=c.Name,img=loadbitmap(activity.getLuaDir().."/file.png")}
      end
    end
  end
  lv.onItemClick=function(l,v,p,s)--列表点击事件
    项目=tostring(v.tag.file.Text)
    if tostring(cp.Text)=="/" then
      路径=ls[p+1]
     else
      路径=ls[p]
    end

    if 项目=="返回上级目录" then
      SetItem(File(cp.Text).getParentFile())
     elseif 路径.isDirectory() then
      SetItem(路径)
     elseif 路径.isFile() then
      callback(tostring(路径))
    end

  end

  SetItem(StartPath)
end


ChoicePath(Environment.getExternalStorageDirectory().toString(),--第一个是路径,第二个是回调函数
function(path)
  print(path)
end)

--[[
*
*----------Dragon be here!----------/
* 　　　┏┓　　　┏┓
* 　　┏┛┻━━━┛┻┓
* 　　┃　　　　　　　┃
* 　　┃　　　━　　　┃
* 　　┃　┳┛　┗┳　┃
* 　　┃　　　　　　　┃
* 　　┃　　　┻　　　┃
* 　　┃　　　　　　　┃
* 　　┗━┓　　　┏━┛
* 　　　　┃　　　┃护国神兽保佑
* 　　　　┃　　　┃代码无BUG！
* 　　　　┃　　　┗━━━┓
* 　　　　┃　　　　　　　┣┓
* 　　　　┃　　　　　　　┏┛
* 　　　　┗┓┓┏━┳┓┏┛
* 　　　　　┃┫┫　┃┫┫
* 　　　　　┗┻┛　┗┻┛
* ━━━━━━神兽出没━━━━━━
]]