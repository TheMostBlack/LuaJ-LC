import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "res"

import "android.graphics.Paint"

activity.setTitle("TitleBar")
activity.setContentView(res.layout.layout)
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF2196F3);

title.getPaint().setFakeBoldText(true)

RippleHelper(btn).RippleColor=0x1CFFFFFF
RippleHelper(btn1).RippleColor=0x1CFFFFFF
RippleHelper(btn2).RippleColor=0x1CFFFFFF
RippleHelper(btn3).RippleColor=0x1CFFFFFF

function btn.onClick()
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end

function btn1.onClick()
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end

function btn2.onClick()
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end

function btn3.onClick()
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end


pop=PopupMenu(activity,menu)
menu=pop.Menu

menu.add("菜单1").onMenuItemClick=function(v)
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end
menu.add("菜单2").onMenuItemClick=function(v)
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end
menu.add("菜单3").onMenuItemClick=function(v)
  Toast.makeText(activity, "Toast",Toast.LENGTH_SHORT).show()
end

btn3.onClick=function()
  pop.show()
end